<html>
<body>
<img src="https://i1.sndcdn.com/artworks-ECpVi36KnxOPRzK6-44czNQ-t500x500.jpg" width="100%" height="100%">
<style>
*{
margin: 0;
}
</style>
</body>
</html>